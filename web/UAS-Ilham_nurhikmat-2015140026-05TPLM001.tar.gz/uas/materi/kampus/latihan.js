var a = 12;
var b = 4;
function perkalianDengan2(b){
	var a = b * 2;
	return a;
}
document.write("<br> dua kali dari b ", b, " adalah ",
	perkalianDengan2(b), "<br>");
document.write("Nilai a adalah ", a);
