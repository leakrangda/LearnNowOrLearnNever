var myArray = new Array();

myArray[0] = "Football";
myArray[1] = "Baseball";
myArray[2] = "Cricket";

document.write(myArray[0] + myArray[1] + myArray[2]);
