function product(a, b){
	return a * b;
}
document.write("<br>",product(4,3),"<br>");
